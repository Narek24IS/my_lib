def narek_func(n):
    print(n)